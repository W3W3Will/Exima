<main id="content" <?php echo e($attributes->merge(['class' => 'flex-grow max-w-screen-xl mx-auto pb-4 md:mb-8 px-4 md:px-8'])); ?>>
    <?php echo e($slot); ?>

</main>
<?php /**PATH C:\xampp\htdocs\exima_project\vendor\filament\filament\src/../resources/views/components/app-content.blade.php ENDPATH**/ ?>