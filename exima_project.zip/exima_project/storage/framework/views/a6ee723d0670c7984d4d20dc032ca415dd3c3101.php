<p
    data-validation-error
    <?php echo e($attributes->class(['filament-forms-field-wrapper-error-message text-sm text-danger-600'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\xampp\htdocs\exima_project\vendor\filament\forms\src\/../resources/views/components/field-wrapper/error-message.blade.php ENDPATH**/ ?>