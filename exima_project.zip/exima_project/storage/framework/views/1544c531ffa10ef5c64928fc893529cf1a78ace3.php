<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\exima_project\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>