<img <?php echo e($attributes->merge([
    'src' => $src(),
    'srcset' => $srcSet(),
    'alt' => $user->name,
    'width' => $size,
    'height' => $size,
    'loading' => 'lazy'
])); ?> />
<?php /**PATH C:\xampp\htdocs\exima_project\vendor\filament\filament\src/../resources/views/components/avatar.blade.php ENDPATH**/ ?>