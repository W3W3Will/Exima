<a
    href="https://github.com/laravel-filament/filament"
    target="_blank"
    rel="noopener noreferrer"
    <?php echo e($attributes->merge(['class' => 'inline-flex items-center opacity-20 hover:opacity-100 transition-opacity duration-500'])); ?>

>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'filament::components.logo','data' => ['class' => 'w-24 h-auto']]); ?>
<?php $component->withName('filament::logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-24 h-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</a>
<?php /**PATH C:\xampp\htdocs\exima_project\vendor\filament\filament\src/../resources/views/components/branding/footer.blade.php ENDPATH**/ ?>