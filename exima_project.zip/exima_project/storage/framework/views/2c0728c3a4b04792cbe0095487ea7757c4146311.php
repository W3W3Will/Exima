<td
    <?php echo e($attributes->class([
        'filament-tables-cell',
        'dark:text-white' => config('tables.dark_mode'),
    ])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH C:\xampp\htdocs\exima_project\vendor\filament\tables\src\/../resources/views/components/cell.blade.php ENDPATH**/ ?>